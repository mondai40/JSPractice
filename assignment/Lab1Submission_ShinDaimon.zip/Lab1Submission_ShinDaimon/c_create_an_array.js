// c) Create an array of numbers named “myArr”. Your array may have any length
//     (try different lengths to test it).

const myArr = [1, 2, 3, 4, 5];

module.exports = myArr;