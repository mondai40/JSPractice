// h) Create an “Employee” object that has the following key-value pairs: 
//  “name”, “email”, “department” and “startDate”.

const Employee = {
    "name": "Shin",
    "email": "tvwmdaimon40@gmail.com",
    "department": "Sales",
    "startDate": 20200501
};

module.exports = Employee;